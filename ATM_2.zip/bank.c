#include<unistd.h>
#include"bank.h"

static int initnum = 22639;

MSG rcvmsg,sndmsg;

int msgsndid,msgrcvid;

//开户
int estab(Account user) 
{
	int fp = open("id",O_RDWR|O_CREAT,0600);
	if(fp == -1)
	{
		perror("estab open fp");
		exit(-1);
	}
	read(fp,&initnum,sizeof(initnum));

	initnum++;
	lseek(fp,0,SEEK_SET);
	write(fp,&initnum,sizeof(initnum));
	close(fp);

	user.id = initnum;
	char buf[1024];
	sprintf(buf,"./message/%d",initnum);
	int fd = open(buf,O_WRONLY|O_CREAT|O_TRUNC,0600);
	if(fd == -1)
	{
		perror("estab open file");
		exit(-1);
	}
	user.cnt=0;
	int res = write(fd,&user,sizeof(user));
	if(res == -1) 
	{
		close(fd);
		return -1;
	}
	else 
	{
		close(fd);
		return initnum;
	}
}
//登录 
int enter(Account user) 
{
	char buf[100];
	sprintf(buf,"./message/%d",user.id);
	int judge = -1;
	if(!access(buf,F_OK)) 
	{
		int fd = open(buf,O_RDWR);
		if(fd != -1) 
		{
			Account psn;
			read(fd,&psn,sizeof(psn));
			if(psn.cnt<3)
			{
				if(psn.pswd == user.pswd) 
				{ 
					close(fd);
					judge = user.id; 
				}
				psn.cnt++;
				lseek(fd,0,SEEK_SET);
				write(fd,&psn,sizeof(psn));
				close(fd);
			}
			else
				judge=-255;
		}
	}
	return judge;
}


//销户
int delete_bank(int id) 
{
	char buf[100];
	sprintf(buf,"./message/%d",id);
	if(!remove(buf))
		return 0;
	else
		return -1;
}


//取钱 
int draw_money(float money,int id) 
{
	char buf[100];
	sprintf(buf,"./message/%d",id);
	int judge = -1;
	int fd = open(buf,O_RDWR);
	if(fd != -1) 
	{
		Account user;
		read(fd,&user,sizeof(user));
		if(user.money > money) 
		{
			user.money -= money;
			lseek(fd,0,SEEK_SET);
			write(fd,&user,sizeof(user));
			close(fd);
			judge = 0;
		}
		return judge;
	}
	else
		return judge;
}


//存钱
int save_money(float money,int id) 
{
	char buf[100];
	sprintf(buf,"./message/%d",id);
	int fd = open(buf,O_RDWR);
	if(fd != -1) 
	{
		Account user;
		read(fd,&user,sizeof(user));
		user.money += money;
		lseek(fd,0,SEEK_SET);
		write(fd,&user,sizeof(user));
		close(fd);
		return 0;
	}
	else
		return -1;
} 


//转账
int transfer(int id1,int id2,float money) 
{
	char buf[100];
	sprintf(buf,"./message/%d",id1);
	int judge = -1;
	int fd1 = open(buf,O_RDWR);
	if(fd1 != -1) 
	{
		Account user;
		sprintf(buf,"./message/%d",id2);
		read(fd1,&user,sizeof(user));
		if(user.money >= money && !access(buf,F_OK)) 
		{
			int fd2 = open(buf,O_RDWR);
			if(fd2 != -1) 
			{
				read(fd1,&user,sizeof(user));
				user.money -= money;
				lseek(fd1,0,SEEK_SET);
				write(fd1,&user,sizeof(user));
				read(fd2,&user,sizeof(user));
				user.money += money;
				lseek(fd2,0,SEEK_SET);
				write(fd2,&user,sizeof(user));
				judge = 0;
			}
			close(fd2);
		}
		close(fd1);
	}
	return judge;
}


//查询
Account find(Account user) 
{
	char buf[100];
	sprintf(buf,"./message/%d",user.id);
	int fd = open(buf,O_RDONLY);
	if(fd != -1) 
	{
		Account user1;
		read(fd,&user1,sizeof(user1));
		close(fd);
		return user1;
	}
	else
		return ;
}
//解锁
int relieve(Account user)
{
	char buf[100];
	int judge=-1;
	sprintf(buf,"./message/%d",user.id);
	int fd = open(buf,O_RDWR);
	if(fd != -1) 
	{
		Account psn;
		read(fd,&psn,sizeof(user));
		if(0==strcmp(psn.name,user.name))
		{
			psn.cnt=0;
			lseek(fd,0,SEEK_SET);
			write(fd,&psn,sizeof(user));
			close(fd);
			judge=0;
		}
	}
	return judge;
}


void print() 
{
	printf("关闭成功!\n");
}

//发送消息队列1
void send_msg(int res) 
{
	if(res>-1) 
	{
		sndmsg.mtype = SUCCESS;
		sndmsg.buf = find(rcvmsg.buf);
		int res1 = msgsnd(msgsndid,&sndmsg,sizeof(sndmsg.buf),0);
		if(res1 == -1)
		{
			perror("server msgsnd");
			exit(-1);
		}	
	}
	else if(res==-255)
	{
		sndmsg.mtype = LOCK;
		sndmsg.buf = rcvmsg.buf;
		int res1 = msgsnd(msgsndid,&sndmsg,sizeof(sndmsg.buf),0);
		if(res1 == -1)
		{	
			perror("server msgsnd");
			exit(-1);
		}
	}
	else
	{
		sndmsg.mtype = FAIL;
		sndmsg.buf = rcvmsg.buf;
		int res1 = msgsnd(msgsndid,&sndmsg,sizeof(sndmsg.buf),0);
		if(res1 == -1)
		{	
			perror("server msgsnd");
			exit(-1);
		}
	}
}
//回收消息队列
void delete_msg(int signo) 
{
	printf("正在关闭服务器....\n");
	sleep(2);
	int res1 = msgctl(msgsndid,IPC_RMID,NULL);
	int res2 = msgctl(msgrcvid,IPC_RMID,NULL);
	if(res1 == -1 || res2 == -1)
	{
		perror("msgctl");
		exit(-1);
	}
	exit(0);
}


//服务端启动
void svst(void) 
{
	pid_t pid = vfork();
	if(!pid) 
	{
		execl("./client","client",NULL);
	}

	msgsndid = msgget(ftok(".",88),IPC_CREAT|0666);
	msgrcvid = msgget(ftok(".",89),IPC_CREAT|0666);
	if(msgsndid == -1||msgrcvid == -1) 
	{
		perror("svr msgget");
		exit(-1);
	}
	sleep(1);
	printf("已经启动!\n");
	signal(SIGINT,delete_msg);//回收消息队列
	while(1) 
	{
		int rcvres = msgrcv(msgrcvid,&rcvmsg,sizeof(rcvmsg.buf),0,0);
		if(rcvres != -1) 
		{
			if(rcvmsg.mtype == ESTAB) 
			{
				//开户
				int id = estab(rcvmsg.buf);
				rcvmsg.buf.id = id;
				send_msg(id);
			}
			else if(rcvmsg.mtype == ENTER) 
			{
				//登录
				int res = enter(rcvmsg.buf);
				send_msg(res);
			}
			else if(rcvmsg.mtype == DELETE) 
			{
				//销户
				int res = delete_bank(rcvmsg.buf.id);
				send_msg(res);
			}

			else if(rcvmsg.mtype == FIND) 
			{
				//查询
				send_msg(0);
			}
			else if(rcvmsg.mtype == DRAW) 
			{
				//取钱
				int res = draw_money(rcvmsg.buf.money,rcvmsg.buf.id);
				send_msg(res);
			}
			else if(rcvmsg.mtype == SAVE) 
			{
				//存钱
				int res = save_money(rcvmsg.buf.money,rcvmsg.buf.id);
				send_msg(res);
			}
			else if(rcvmsg.mtype == TRANSFER)
			{
				//转账
				int res = transfer(rcvmsg.buf.id,rcvmsg.buf.pswd,rcvmsg.buf.money);

				send_msg(res);
			}
			else if(rcvmsg.mtype == UNLOCK)
			{
				//解锁
				int res = relieve(rcvmsg.buf);
				send_msg(res);
			}
		}
	}
}

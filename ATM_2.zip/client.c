#include <stdbool.h>
#include "bank.h"
#include "project.c"
//清理输入缓冲区
void clear_stdin(void)
{
	stdin->_IO_read_ptr = stdin->_IO_read_end;
}
//获取指令
char get_cmd(char start,char end)
{
//	clear_stdin();

	printf("请输入指令:");
	while(true)
	{
		char val = getch();
		if(val >= start && val <= end)
		{
			printf("%c\n",val);
			return val;
		}
	}
}
int _enter()
{
	int num = -1;

	do {
		system("clear");
		printf("   -------交易类型------\n");
		printf("\n");
		printf("	1.取钱	2.存钱\n");
		printf("\n");
		printf("	3.查询	4.转账\n");
		printf("\n");
		printf("	5.销户	6.退出\n");
		printf("\n");
		printf("   ---------------------\n");
		switch(get_cmd('1','6')) 
		{
			case '1':
				draw_money();
				break;
			case '2':
				save_money();
				break;
			case '3':
				find_money();
				break;
			case '4':
				transfer_money();
				break;
			case '5':
				if(!bank_delete()) 
				{
					num = 0;
					printf("销户成功,欢迎下次使用!\n");
					sleep(2);
				}
					break;
			case '6':  num = 0;
				break;
			default:
				break;
		}
	} while(num);
	return num ;
}
int main() {
	get_ID();
	int num = -1;
	sleep(2);
	do{
		system("clear");
		printf("--------指针bank--------\n");
		printf("\n");
		printf("        1.开户	      \n");
		printf("        2.登录	      \n");
		printf("        3.解锁	      \n");
		printf("        4.退出	      \n");
		printf("\n");
		printf("------------------------\n");
		switch(get_cmd('1','4'))
			{
				case '1': bank_estab(); break;
				case '2':
					if(!bank_enter()) 
					{ 
						_enter();
					}
					break;
				case '3': 
						unlock_id(); 
						break;
				case '4':
					num=0;
						break;
				default: 
				num=0; break;
			}
		}while(num);
		return 0;
}

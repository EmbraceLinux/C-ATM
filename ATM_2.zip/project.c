//交易类型
#include"bank.h"

int id;

MSG rcv_msg,snd_msg;

int msgsndid;

int msgrcvid;


void get_ID() 
{
	 msgsndid = msgget(ftok(".",89),0);
	 msgrcvid = msgget(ftok(".",88),0);
	if(msgsndid == -1||msgrcvid == -1)
	{
		perror("client msgget");
		exit(-1);
	}
}
void anony_key(void)
{
	stdin->_IO_read_ptr = stdin->_IO_read_end;
	printf("按任意键继续...");
	getch();
}

//退出
void exit_bank() 
{
	anony_key();
}

//开户
void bank_estab() 
{
	Account user;
	printf("请输入姓名:");
	scanf("%s",user.name);
	printf("请输入密码(数字):");
	scanf("%d",&user.pswd);
	printf("请存入金额:");
	scanf("%f",&user.money);
	snd_msg.mtype = ESTAB;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}

	memset(&rcv_msg.buf,0,sizeof(rcv_msg.buf));
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else 
	{
		if(rcv_msg.mtype == SUCCESS) 
		{
			printf("处理成功!\n您的帐号:  %d\n请牢记!\n",rcv_msg.buf.id);
		}
		else
		{
			printf("服务器正在升级...!\n");
			exit_bank();
		}
	}
}
//销户
int bank_delete() 
{
	snd_msg.mtype = DELETE;
	snd_msg.buf.id = id;
	int judge = -1;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
			judge = 0;
	}
	return judge;
}
//登录
int bank_enter() 
{
	Account user;
	int judge = -1;
	printf("请输入帐号:");
	scanf("%d",&user.id);
	printf("请输入密码:");
	stdin->_IO_read_ptr = stdin->_IO_read_end;
	scanf("%d",&user.pswd);
	snd_msg.mtype = ENTER;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}
	memset(&rcv_msg.buf,0,sizeof(rcv_msg.buf));
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			id = rcv_msg.buf.id;
			printf("成功登陆!\n");
			judge = 0;
		}
		if(rcv_msg.mtype == FAIL)
		{
			printf("帐号或密码错误...\n");
		}
		if(rcv_msg.mtype == LOCK)
		{
			printf("该帐号已冻结...\n");
		}
	}
	return judge;
}
//取钱
void draw_money() {
	Account user;
	printf("请输入取款金额:");
	scanf("%f",&user.money);
	user.id = id;
	snd_msg.mtype = DRAW;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			printf("处理成功!\n当前余额%6.2f\n",rcv_msg.buf.money);
			exit_bank();
		}
		else 
		{
			printf("您的账户余额不足\n");
			exit_bank();
		}
	}
}
//存钱
void save_money() 
{
	Account user;
	printf("请输入存款金额:");
	scanf("%f",&user.money);
	user.id = id;
	snd_msg.mtype = SAVE;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			printf("处理成功!\n当前余额%6.2f\n",rcv_msg.buf.money);
			exit_bank();
		}
		else
		{
			printf("服务器正在升级...\n");
			exit_bank();
		}
	}
}
//转账
void transfer_money() 
{
	Account user;
	printf("请输入帐号:");
	scanf("%d",&user.pswd);
	printf("请输入转账金额:");
	scanf("%f",&user.money);
	user.id = id;
	snd_msg.mtype = TRANSFER;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
	{
		perror("bank_estab msgsnd");
		exit(-1);
	}
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
	{
		perror("bank_estab msgrcv");
		exit(-1);
	}
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			printf("处理成功!\n您当前账户的余额%6.2f\n",rcv_msg.buf.money);
			exit_bank();
		}
		else 
		{
			printf("该帐号不存在或您的账户余额不足\n");
			exit_bank();
		}
	}
}
//查询
void find_money() 
{
	snd_msg.mtype = FIND;
	snd_msg.buf.id = id;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
		perror("bank_estab msgsnd"),exit(-1);
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
		perror("bank_estab msgrcv"),exit(-1);
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			printf("处理成功!\n姓名:%s\n帐号:%d\n余额:%6.2f\n",rcv_msg.buf.name,rcv_msg.buf.id,rcv_msg.buf.money);
			exit_bank();
		}
		else
		{
			printf("服务器正在升级...\n");
			exit_bank();
		}
	}
}
//解锁
void unlock_id()
{
	Account user;
	int judge = -1;
	printf("请输入帐号:");
	scanf("%d",&user.id);
	stdin->_IO_read_ptr = stdin->_IO_read_end;
	printf("请输入户主姓名:");
	scanf("%s",user.name);
	snd_msg.mtype = UNLOCK;
	snd_msg.buf = user;
	int res1 = msgsnd(msgsndid,&snd_msg,sizeof(snd_msg.buf),0);
	if(res1 == -1)
		perror("bank_estab msgsnd"),exit(-1);
	int res = msgrcv(msgrcvid,&rcv_msg,sizeof(rcv_msg),0,0);
	if(res == -1)
		perror("bank_estab msgrcv"),exit(-1);
	else 
	{
		if(rcv_msg.mtype == SUCCESS)
		{
			printf("账户已解锁...\n");
			exit_bank();
		}
		else
		{
			printf("账户解锁失败...\n");
			exit_bank();
		}
	}

}

#include "bank.h"
#include "bank.c"
int main() 
{
	atexit(print);
	printf("正在启动....\n");
	svst();
	return 0;
}

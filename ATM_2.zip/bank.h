#ifndef    BANK_H
#define    BANK_H

#define  ESTAB    1  //开户
#define  ENTER    2  //登录
#define  DELETE   3  //销户
#define  FIND     4  //查询
#define  DRAW     5  //取钱
#define  SAVE     6  //存钱
#define  TRANSFER 7  //转账
#define  UNLOCK   8  //解锁
#define  LOCK     9

#define  SUCCESS  10 //处理成功
#define  FAIL     11 //处理失败

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<signal.h>
#include<sys/msg.h>
#include<string.h>
#include<getch.h>
#include<dirent.h>
#include<unistd.h>


typedef struct Account {
	int id;
	char name[100];
	int pswd; 
	float money;
	int cnt;
} Account;

typedef struct MSG {
	long mtype;
	long state;
	Account buf;
} MSG;

void svst(void);
#endif  //BANK_H
